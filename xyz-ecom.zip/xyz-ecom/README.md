# xyz-ecom
* Design<br>
#####Database<br>
* Product Repository<br>
* Seller Repository<br>
**Schemas are scalable to accommodate any type of seller and any type of products and any number of regions.
* In-Memory db has been used

#####API's
* Seller API's
    * All Retrieval API's
    * Buy API to buy a particular product from seller
    * All CRUD API's
* Product API
    * All  Retrieval API's
    * All CRUD API's
    * Group By Price, Size, Color, Brand
    
#####Caching
* Cache Refresh interval is every 2 hours 
* Cache is applied on retrieve operations

#####Exception Handling
* Exception handling is done at global controller level

#####Unit Testing
* Unit test covered for a repository and service testing.


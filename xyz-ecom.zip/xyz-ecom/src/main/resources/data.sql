//brand
DROP TABLE IF EXISTS brand;
insert into brand values ('1A','LifeStyleStores','India');
insert into brand values ('2A','Jack&Jones','UK');
insert into brand values ('3A','Samsung','Korea');
insert into brand values ('4A','Apple','US');

//Category
DROP TABLE IF EXISTS category;
insert into category values ('C1','Electronics');
insert into category values ('C2','Apparels');
insert into category values ('C3','Health');
insert into category values ('C4','Furniture');
insert into category values ('C5','Mobiles');

//sub-category
DROP TABLE IF EXISTS category_sub_categories;
insert into category_sub_categories values ('C1','C5');

//Color
DROP TABLE IF EXISTS color;
insert into color values ('1','Red');
insert into color values ('2','Green');
insert into color values ('3','Blue');
insert into color values ('4','Yellow');
insert into color values ('5','Black');
insert into color values ('6','White');

//Size
DROP TABLE IF EXISTS size;
insert into size  values ('XL','India','Uni body','{"thickness":1.5}','C5');
insert into size  values ('A_I_M','India','Medium India','{"length":34,"Waist":34,"Pattern":"SlimFit"}','C2');
insert into size  values ('A_I_L','India','Large India','{"length":38,"Waist":38,"Pattern":"Regular"}','C2');

//Product
DROP TABLE IF EXISTS product;
insert into product values ('P1','112233','Mobiles & Communications','{"RAM":"12GB"}','Iphone 11','70000','4A','C5','3','XL');
insert into product values ('P2','11223344','Clothing','{"Fabric":"Linen"}','Trouser','7000','2A','C2','6','A_I_M');
insert into product values ('P3','1122334455','Clothing','{"Fabric":"Cotton"}','Trouser','7000','2A','C2','6','A_I_L');

//Seller
DROP TABLE IF EXISTS seller;
insert into seller values ('1',50,'1A','Amazon',500,'P1');
insert into seller values ('2',150,'2B','Myntra',1500,'P2');
insert into seller values ('3',200,'3C','Flipkart',3500,'P3');
insert into seller values ('4',2001,'1A','Amazon',7100,'P3');
/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.services;

import com.xyz.ecom.domain.product.Product;
import com.xyz.ecom.repository.ProductRepository;
import com.xyz.ecom.repository.result.CountProductByBrand;
import com.xyz.ecom.repository.result.CountProductByColor;
import com.xyz.ecom.repository.result.CountProductByPrice;
import com.xyz.ecom.repository.result.CountProductBySize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    /**
     * Retrieves All Available Products
     *
     * @return List of Product
     */
    public List<Product> retrieveAll() {
        return (List<Product>) productRepository.findAll();
    }

    /**
     * Product Group by Brand
     *
     * @return CountProductByBrand
     */
    public List<CountProductByBrand> retrieveByBrand() {
        return productRepository.groupByBrand();
    }

    /**
     * Groups by Color
     *
     * @return CountProductByColor
     */
    public List<CountProductByColor> retrieveByColor() {
        return productRepository.groupByColor();
    }

    /**
     * Groups by Price
     *
     * @return CountProductByPrice
     */
    public List<CountProductByPrice> retrieveByPrice() {
        return productRepository.groupByPrice();
    }

    /**
     * Groups by Size
     *
     * @return CountProductBySize
     */
    public List<CountProductBySize> retrieveBySize() {
        return productRepository.groupBySize();
    }

    /**
     * Retrieves Product by skuID
     *
     * @param skUID
     * @return Product
     */
    public Product retrieveBySKUID(BigInteger skUID) {
        return productRepository.findBySKU(skUID);
    }
}

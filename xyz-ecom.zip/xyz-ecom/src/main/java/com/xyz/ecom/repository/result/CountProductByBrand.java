/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository.result;

import com.xyz.ecom.domain.brands.Brand;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@ToString
public class CountProductByBrand {

    private Brand brand;
    private long count;


}

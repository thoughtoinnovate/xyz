/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.domain.seller;

import com.xyz.ecom.domain.product.Product;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigInteger;

@RequiredArgsConstructor
@Getter
@ToString
@Entity
public class Seller {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private BigInteger id;

    @GeneratedValue(strategy = GenerationType.AUTO)
    private String code;
    private String name;
    @ManyToOne
    private Product product;
    @Setter
    private BigInteger availableStock;
    private BigInteger totalStock;
}

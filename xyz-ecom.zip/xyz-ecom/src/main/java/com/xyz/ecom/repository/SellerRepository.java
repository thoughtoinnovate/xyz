/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository;

import com.xyz.ecom.domain.product.Product;
import com.xyz.ecom.domain.seller.Seller;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;

public interface SellerRepository extends CrudRepository<Seller, BigInteger> {
    @Query(value="select s from Seller s  where product.code = :productCode",nativeQuery = false)
    public Seller findAvailableStockOfProductBySeller(String productCode);

    @Query(value="select s.product from Seller s  where s.code = :sellerCode",nativeQuery = false)
    public List<Product> findAllProductsBySeller(String sellerCode);

    @Query(value="select s from Seller s  where s.code = :sellerCode and s.availableStock>0",nativeQuery = false)
    public List<Seller> findAvailableProductsBySeller(String sellerCode);

    @Query(value="select s from Seller s  where s.code = :sellerCode and s.product.code =:productCode",nativeQuery = false)
    public Seller findSellerProduct(String sellerCode,String productCode);

}

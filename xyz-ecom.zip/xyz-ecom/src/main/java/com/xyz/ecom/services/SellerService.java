/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.services;

import com.xyz.ecom.domain.product.Product;
import com.xyz.ecom.domain.seller.Seller;
import com.xyz.ecom.repository.SellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;

@Service
public class SellerService {

    @Autowired
    private SellerRepository sellerRepository;

    /**
     * Retrieves all sellers
     *
     * @return List of Sellers
     */
    public List<Seller> retrieveAllSellers() {
        return (List<Seller>) sellerRepository.findAll();
    }

    /**
     * Finds all products for a seller
     *
     * @param sellerCode
     * @return List of Products
     */
    public List<Product> retrieveAllProducts(String sellerCode) {
        return (List<Product>) sellerRepository.findAllProductsBySeller(sellerCode);
    }

    /**
     * Finds Available products a seller
     *
     * @param sellerCode
     * @return List of Product
     */
    public List<Product> retrieveAvailableProducts(String sellerCode) {
        return (List<Product>) sellerRepository.findAvailableStockOfProductBySeller(sellerCode);
    }

    /**
     * Buy particular product of a seller
     *
     * @param seller_code
     * @param product_code
     * @return {@link Seller}
     */
    public Seller buyProduct(String seller_code, String product_code) {

        Seller sellerProduct = sellerRepository.findSellerProduct(seller_code, product_code);

        if (null == sellerProduct || sellerProduct.getAvailableStock().compareTo(BigInteger.ONE) < 0) {
            throw new RuntimeException("Product not listed by Seller");
        }

        sellerProduct.setAvailableStock(sellerProduct.getAvailableStock().subtract(BigInteger.ONE));
        sellerRepository.save(sellerProduct);
        return sellerProduct;

    }
}

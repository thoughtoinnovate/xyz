/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.domain.converters;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.AttributeConverter;
import java.util.Map;

@Component
public class HashMapConverter implements AttributeConverter<Map<String, Object>, String> {

    @Autowired
    ObjectMapper objectMapper;

    @Override
    public String convertToDatabaseColumn(Map<String, Object> featureMap) {

        if(null==objectMapper){
            objectMapper=new ObjectMapper();
        }

        String customerInfoJson = null;
        try {
            customerInfoJson = objectMapper.writeValueAsString(featureMap);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return customerInfoJson;
    }

    @Override
    public Map<String, Object> convertToEntityAttribute(String customerInfoJSON) {

        if(null==objectMapper){
            objectMapper=new ObjectMapper();
        }

        Map<String, Object> customerInfo = null;
        try {
            customerInfo = objectMapper.readValue(customerInfoJSON, Map.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return customerInfo;
    }

}
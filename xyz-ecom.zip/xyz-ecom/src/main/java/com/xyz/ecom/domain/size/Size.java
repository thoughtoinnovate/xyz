
package com.xyz.ecom.domain.size;

import com.xyz.ecom.domain.categories.Category;
import com.xyz.ecom.domain.converters.HashMapConverter;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Map;

@RequiredArgsConstructor
@Getter
@Entity
@ToString
public class Size {
    @Id
    @GeneratedValue(strategy =  GenerationType.AUTO)
    private String code;
    private String country;
    @Convert(converter = HashMapConverter.class)
    private Map<String,Object> size;
    @OneToOne
    private Category category;
    private String details;
}
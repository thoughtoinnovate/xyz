package com.xyz.ecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Date;

@SpringBootApplication
@EnableCaching
@EnableScheduling
public class XyzEcomApplication {

    public static void main(String[] args) {
        SpringApplication.run(XyzEcomApplication.class, args);
    }

    /**
     * Refresh Intervals Set as per application properties
     */
    @Scheduled(fixedRateString = "${cache.refresh.freq.in.milliseconds}")
    @CacheEvict(cacheNames = {"sellers_all", "products_all"}, allEntries = true)
    public void clearCache() {
        System.out.println(new Date() + " Refreshing Cache...");
    }

}

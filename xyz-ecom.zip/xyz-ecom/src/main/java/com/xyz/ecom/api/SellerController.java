/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.api;

import com.xyz.ecom.domain.seller.Seller;
import com.xyz.ecom.services.SellerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class SellerController {

    @Autowired
    private SellerService sellerService;

    @Cacheable("sellers_all")
    @GetMapping("/sellers")
    public ResponseEntity<List<Seller>> getSellers() throws InterruptedException {
        List<Seller> sellers = sellerService.retrieveAllSellers();
        return new ResponseEntity<>(sellers, HttpStatus.OK);
    }

    @GetMapping("/sellers/{seller_code}/{product_code}/buy")
    public ResponseEntity<Seller> buyProduct(@PathVariable String seller_code, @PathVariable String product_code) {
        final Seller seller = sellerService.buyProduct(seller_code, product_code);
        return new ResponseEntity<>(seller, HttpStatus.OK);
    }
}

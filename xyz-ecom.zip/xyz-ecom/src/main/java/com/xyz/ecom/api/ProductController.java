/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.api;

import com.xyz.ecom.domain.product.Product;
import com.xyz.ecom.repository.result.CountProductByBrand;
import com.xyz.ecom.repository.result.CountProductByColor;
import com.xyz.ecom.repository.result.CountProductByPrice;
import com.xyz.ecom.repository.result.CountProductBySize;
import com.xyz.ecom.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    @Cacheable("products_all")
    @GetMapping("/products")
    public ResponseEntity<List<Product>> retrieveAll() {
        List<Product> products = productService.retrieveAll();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @Cacheable("products_brand")
    @GetMapping("/products/brand")
    public ResponseEntity<List<CountProductByBrand>> retrieveCountByBrand() {
        return new ResponseEntity<>(productService.retrieveByBrand(), HttpStatus.OK);
    }

    @Cacheable("products_price")
    @GetMapping("/products/price")
    public ResponseEntity<List<CountProductByPrice>> retrieveCountByPrice() {
        return new ResponseEntity<>(productService.retrieveByPrice(), HttpStatus.OK);
    }

    @Cacheable("products_color")
    @GetMapping("/products/color")
    public ResponseEntity<List<CountProductByColor>> retrieveCountByColor() {
        return new ResponseEntity<>(productService.retrieveByColor(), HttpStatus.OK);
    }

    @Cacheable("products_size")
    @GetMapping("/products/size")
    public ResponseEntity<List<CountProductBySize>> retrieveCountBySize() {
        return new ResponseEntity<>(productService.retrieveBySize(), HttpStatus.OK);
    }

    @Cacheable("products_sku")
    @GetMapping("/products/sku/{sku_id}")
    public ResponseEntity<Product> retrieveCountBySKUID(@PathVariable String sku_id) {
        Product product = productService.retrieveBySKUID(new BigInteger(sku_id));
        HttpStatus found = (null != product) ? HttpStatus.FOUND : HttpStatus.NOT_FOUND;
        return new ResponseEntity<>(product, found);
    }

}

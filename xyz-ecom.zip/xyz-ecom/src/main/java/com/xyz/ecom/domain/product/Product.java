package com.xyz.ecom.domain.product;

import com.xyz.ecom.domain.brands.Brand;
import com.xyz.ecom.domain.categories.Category;
import com.xyz.ecom.domain.colors.Color;
import com.xyz.ecom.domain.converters.HashMapConverter;
import com.xyz.ecom.domain.size.Size;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;

@RequiredArgsConstructor
@Getter
@Entity
@ToString
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String code;
    private String name;
    @OneToOne
    private Brand brand;
    @OneToOne
    private Category category;

    @OneToOne
    private Color color;

    @OneToOne
    private Size size;

    private BigInteger SKU;
    private BigDecimal price;
    private String description;

    @Convert(converter = HashMapConverter.class)
    private Map<String,Object> features;
}

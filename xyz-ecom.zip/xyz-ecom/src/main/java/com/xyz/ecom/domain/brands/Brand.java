
/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.domain.brands;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
@RequiredArgsConstructor
@Getter
@ToString
public class Brand {

    @Id
    @GeneratedValue(strategy =  GenerationType.AUTO)
    private String code;
    private String name;
    private String origin;
}

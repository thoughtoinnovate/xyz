/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository.result;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;

@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@ToString
public class CountProductByPrice {
    private BigDecimal price;
    private long count;
}

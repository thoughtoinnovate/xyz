/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository;

import com.xyz.ecom.domain.product.Product;
import com.xyz.ecom.repository.result.CountProductByBrand;
import com.xyz.ecom.repository.result.CountProductByColor;
import com.xyz.ecom.repository.result.CountProductByPrice;
import com.xyz.ecom.repository.result.CountProductBySize;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.math.BigInteger;
import java.util.List;

public interface ProductRepository extends CrudRepository<Product, String> {

    @Query(value = "select new com.xyz.ecom.repository.result.CountProductByBrand(brand,count(*)) " +
            "from Product group by brand_code")
    List<CountProductByBrand> groupByBrand();

    @Query(value = "select new com.xyz.ecom.repository.result.CountProductByPrice(price,count(*)) from Product group by price", nativeQuery = false)
    List<CountProductByPrice> groupByPrice();

    @Query(value = "select new com.xyz.ecom.repository.result.CountProductByColor(color,count(*)) from Product group by color_code",nativeQuery=false)
    List<CountProductByColor> groupByColor();


    @Query(value = "select new com.xyz.ecom.repository.result.CountProductBySize(size,count(*)) from Product group by size",nativeQuery=false)
    List<CountProductBySize> groupBySize();

    @Query(value="select p from Product p where p.SKU = :skuID",nativeQuery = false)
    Product findBySKU(BigInteger skuID);
}

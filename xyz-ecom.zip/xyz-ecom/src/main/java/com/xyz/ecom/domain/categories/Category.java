package com.xyz.ecom.domain.categories;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@RequiredArgsConstructor
@Getter
@ToString
public class Category {
    @Id
    @GeneratedValue(strategy =  GenerationType.AUTO)
    private String code;
    private String type;
    @ElementCollection
    private List<Category> subCategories;

}


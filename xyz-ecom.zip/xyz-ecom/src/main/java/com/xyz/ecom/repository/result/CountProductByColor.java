/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository.result;

import com.xyz.ecom.domain.colors.Color;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@ToString
public class CountProductByColor {
    private Color color;
    private long count;
}

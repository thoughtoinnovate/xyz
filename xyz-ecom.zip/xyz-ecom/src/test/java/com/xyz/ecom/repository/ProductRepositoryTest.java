/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository;

import com.xyz.ecom.repository.result.CountProductByBrand;
import com.xyz.ecom.repository.result.CountProductByColor;
import com.xyz.ecom.repository.result.CountProductByPrice;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.math.BigInteger;
import java.util.List;


@DataJpaTest
class ProductRepositoryTest {

    @Autowired
    TestEntityManager testEntityManager;

    @Autowired
    ProductRepository productRepository;


    @Test
    void groupByBrand() {
        List<CountProductByBrand> countProductByBrands = productRepository.groupByBrand();
        Assertions.assertNotNull(countProductByBrands);
    }

    @Test
    void groupByPrice() {
        List<CountProductByPrice> groupByPrice = productRepository.groupByPrice();
        Assertions.assertNotNull(groupByPrice);
    }

    @Test
    void groupByColor() {
        List<CountProductByColor> countProductByColors = productRepository.groupByColor();
        Assertions.assertNotNull(countProductByColors);
    }

    @Test
    void groupBySize() {
        Assertions.assertNotNull(productRepository.groupBySize());
    }

    @Test
    void findBySKU() {
        Assertions.assertNotNull(productRepository.findBySKU(BigInteger.valueOf(11223344)));
    }
}
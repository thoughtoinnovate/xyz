package com.xyz.ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XyzEcomApplicationTests {

	@Test
	void contextLoads() {
	}

}

/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.services;

import com.xyz.ecom.domain.seller.Seller;
import jdk.nashorn.internal.AssertsEnabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class SellerServiceTest {

    @Autowired
    SellerService sellerService;

    @Test
    void buyProduct() {
        Seller p1 = sellerService.buyProduct("1A", "P1");
        Assert.isTrue(p1.getAvailableStock().compareTo(new BigInteger("49"))==0);
    }
}
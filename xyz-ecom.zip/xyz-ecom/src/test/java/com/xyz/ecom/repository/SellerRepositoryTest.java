/*
 * Copyright (c) 2020
 */

package com.xyz.ecom.repository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.math.BigInteger;

@DataJpaTest
class SellerRepositoryTest {

    @Autowired
    SellerRepository sellerRepository;

    @Test
    void findAvailableStockOfProductBySeller() {
        Assertions.assertNotNull(sellerRepository.findAvailableStockOfProductBySeller("P2"));
    }

    @Test
    void findAllProductBySeller() {
        Assertions.assertNotNull(sellerRepository.findAllProductsBySeller("1A"));
    }

    @Test
    void findAvailableProductsBySeller() {
        Assertions.assertNotNull(sellerRepository.findAvailableProductsBySeller("1A"));
    }

    @Test
    void findSellerProduct() {
        Assertions.assertNotNull(sellerRepository.findSellerProduct("1A","P1"));
    }
}
